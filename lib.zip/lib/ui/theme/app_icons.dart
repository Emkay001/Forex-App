part of 'theme.dart';

class AppIcon {
  AppIcon._();

  static const _kFontFam = 'TwitterIcon';

  static const IconData fabTweet = IconData(0xf029, fontFamily: _kFontFam);
  static const IconData messageEmpty = IconData(0xf187, fontFamily: _kFontFam);
  static const IconData messageFill = IconData(0xf554, fontFamily: _kFontFam);
  static const IconData search = IconData(0xf058, fontFamily: _kFontFam);
  static const IconData searchFill = IconData(0xf558, fontFamily: _kFontFam);
  static const IconData pause = IconData(0xf558, fontFamily: _kFontFam);
  static const IconData gameFill = IconData(0xf558, fontFamily: _kFontFam);
  static const IconData notification = IconData(0xf055, fontFamily: _kFontFam);
  static const IconData notificationFill =
      IconData(0xf019, fontFamily: _kFontFam);
  static const IconData messageFab = IconData(0xf053, fontFamily: _kFontFam);
  static const IconData blog = IconData(0xf205, fontFamily: _kFontFam);
  static const IconData about = IconData(0xf208, fontFamily: _kFontFam);
  static const IconData feed = IconData(0xf211, fontFamily: _kFontFam);

  static const IconData home = IconData(0xf053, fontFamily: _kFontFam);
  static const IconData homeFill = IconData(0xF553, fontFamily: _kFontFam);
  static const IconData heartEmpty = IconData(0xf148, fontFamily: _kFontFam);
  static const IconData heartFill = IconData(0xf015, fontFamily: _kFontFam);
  static final IconData settings = IconData(0xf059, fontFamily: _kFontFam);
  static final IconData adTheRate = IconData(0xf064, fontFamily: _kFontFam);
  static final IconData reply = IconData(0xf151, fontFamily: _kFontFam);
  static final IconData retweet = IconData(0xf152, fontFamily: _kFontFam);
  static final IconData image = IconData(0xf109, fontFamily: _kFontFam);
  static final IconData camera = IconData(0xf110, fontFamily: _kFontFam);
  static final IconData arrowDown = IconData(0xf196, fontFamily: _kFontFam);
  static final IconData blueTick = IconData(0xf099, fontFamily: _kFontFam);
  static final IconData link = IconData(0xf098, fontFamily: _kFontFam);
  static final IconData helped = IconData(0xf000, fontFamily: _kFontFam);
  static final IconData cookie = IconData(0xf205, fontFamily: _kFontFam);
  static final IconData cookies = IconData(0xf215, fontFamily: _kFontFam);
  static final IconData profiles = IconData(0xf002, fontFamily: _kFontFam);
  static final IconData logout = IconData(0xf222, fontFamily: _kFontFam);
  static final IconData agreement = IconData(0xf047, fontFamily: _kFontFam);
  static final IconData privacy = IconData(0xf009, fontFamily: _kFontFam);
  static final IconData unFollow = IconData(0xf097, fontFamily: _kFontFam);
  static final IconData mute = IconData(0xf101, fontFamily: _kFontFam);
  static final IconData viewHidden = IconData(0xf156, fontFamily: _kFontFam);
  static final IconData block = IconData(0xe609, fontFamily: _kFontFam);
  static final IconData report = IconData(0xf038, fontFamily: _kFontFam);
  static final IconData pin = IconData(0xf088, fontFamily: _kFontFam);
  static final IconData delete = IconData(0xf154, fontFamily: _kFontFam);
  static final IconData profile = IconData(0xf056, fontFamily: _kFontFam);
  static final IconData lists = IconData(0xf094, fontFamily: _kFontFam);
  static final IconData bookmark = IconData(0xf155, fontFamily: _kFontFam);
  static final IconData moments = IconData(0xf160, fontFamily: _kFontFam);
  static final IconData twitterAds = IconData(0xf504, fontFamily: _kFontFam);
  static final IconData bulb = IconData(0xf567, fontFamily: _kFontFam);
  static final IconData newMessage = IconData(0xf035, fontFamily: _kFontFam);
  static final IconData bell = IconData(0xf035, fontFamily: _kFontFam);
  static final IconData play = IconData(0xf022, fontFamily: _kFontFam);
  static final IconData agree = IconData(0xf220, fontFamily: _kFontFam);
  static final IconData pausegame = IconData(0xf302, fontFamily: _kFontFam);
  static final IconData loud = IconData(0xf070, fontFamily: _kFontFam);
  static final IconData profiled = IconData(0xf002, fontFamily: _kFontFam);
  static final IconData mentor = IconData(0xf105, fontFamily: _kFontFam);
  static final IconData post = IconData(0xf065, fontFamily: _kFontFam);
  static final IconData reuse = IconData(0xf210, fontFamily: _kFontFam);
  static final IconData sadFace = IconData(0xf430, fontFamily: _kFontFam);
  static final IconData bulbOn = IconData(0xf066, fontFamily: _kFontFam);
  static final IconData bulbOff = IconData(0xf567, fontFamily: _kFontFam);
  static final IconData follow = IconData(0xf175, fontFamily: _kFontFam);
  static final IconData thumbpinFill = IconData(0xf003, fontFamily: _kFontFam);
  static final IconData calender = IconData(0xf203, fontFamily: _kFontFam);
  static final IconData locationPin = IconData(0xf031, fontFamily: _kFontFam);
  static final IconData edit = IconData(0xf112, fontFamily: _kFontFam);
}
