import 'package:flutter/material.dart';
import 'package:one_gov_fx/helper/utility.dart';
import 'package:one_gov_fx/ui/page/settings/widgets/headerWidget.dart';
import 'package:one_gov_fx/ui/page/settings/widgets/settingsRowWidget.dart';
import 'package:one_gov_fx/ui/theme/theme.dart';
import 'package:one_gov_fx/widgets/customAppBar.dart';
import 'package:one_gov_fx/widgets/customWidgets.dart';

class AboutPage extends StatelessWidget {
  const AboutPage({Key key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: TwitterColor.white,
      appBar: CustomAppBar(
        isBackButton: true,
        title: customTitleText(
          'About One Government FX',
        ),
      ),
      body: ListView(
        physics: BouncingScrollPhysics(),
        children: <Widget>[
          HeaderWidget(
            'Help',
            secondHeader: true,
          ),
          SettingRowWidget(
            "Help Centre",
            vPadding: 0,
            showDivider: false,
            onPressed: () {
              Utility.launchURL(
                  "https://github.com/TheAlphamerc/one_gov_fx/issues");
            },
          ),
          HeaderWidget('Legal'),
          SettingRowWidget(
            "Terms of Service",
            showDivider: true,
            onPressed: () {
              Utility.launchURL(
                  "https://github.com/TheAlphamerc/one_gov_fx/issues");
            },
          ),
          SettingRowWidget(
            "Privacy policy",
            showDivider: true,
            onPressed: () {
              Utility.launchURL(
                  "https://github.com/TheAlphamerc/one_gov_fx/issues");
            },
          ),
          SettingRowWidget(
            "Cookie use",
            showDivider: true,
            onPressed: () {
              Utility.launchURL(
                  "https://github.com/TheAlphamerc/one_gov_fx/issues");
            },
          ),
          SettingRowWidget(
            "Legal notices",
            showDivider: true,
            onPressed: () async {
              showLicensePage(
                context: context,
                applicationName: 'One Gov FX',
                applicationVersion: '1.0.0',
                useRootNavigator: true,
              );
            },
          ),
          HeaderWidget('Developer'),
          SettingRowWidget("Github", showDivider: true, onPressed: () {
            Utility.launchURL("https://github.com/TheAlphamerc");
          }),
          SettingRowWidget("LinkidIn", showDivider: true, onPressed: () {
            Utility.launchURL("https://www.linkedin.com/in/thealphamerc/");
          }),
          SettingRowWidget("Twitter", showDivider: true, onPressed: () {
            Utility.launchURL("https://twitter.com/TheAlphaMerc");
          }),
          SettingRowWidget("Blog", showDivider: true, onPressed: () {
            Utility.launchURL("https://dev.to/thealphamerc");
          }),
        ],
      ),
    );
  }
}
