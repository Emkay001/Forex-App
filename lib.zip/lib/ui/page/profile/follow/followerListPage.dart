import 'package:flutter/material.dart';
import 'package:one_gov_fx/model/user.dart';
import 'package:one_gov_fx/ui/page/common/usersListPage.dart';

class FollowerListPage extends StatelessWidget {
  FollowerListPage({Key key, this.userList, this.profile}) : super(key: key);
  final List<String> userList;
  final UserModel profile;

  static MaterialPageRoute getRoute(
      {List<String> userList, UserModel profile}) {
    return MaterialPageRoute(
      builder: (BuildContext context) {
        return FollowerListPage(
          profile: profile,
          userList: userList,
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return UsersListPage(
      pageTitle: 'Connections',
      userIdsList: userList,
      emptyScreenText: '${profile?.userName} doesn\'t have any connections',
      emptyScreenSubTileText:
          'When someone connects with them, they\'ll be listed here.',
    );
  }
}
