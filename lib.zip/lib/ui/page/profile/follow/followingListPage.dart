import 'package:flutter/material.dart';
import 'package:one_gov_fx/state/authState.dart';
import 'package:one_gov_fx/ui/page/common/usersListPage.dart';
import 'package:provider/provider.dart';

class FollowingListPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    var state = Provider.of<AuthState>(context);
    return UsersListPage(
        pageTitle: 'Mentors',
        userIdsList: state.profileUserModel.followingList,
        emptyScreenText:
            '${state?.profileUserModel?.userName ?? state.userModel.userName} doesn\'t have any mentors yet',
        emptyScreenSubTileText: 'When they do they\'ll be listed here.');
  }
}
