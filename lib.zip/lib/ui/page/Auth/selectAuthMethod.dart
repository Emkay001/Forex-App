import 'package:flutter/material.dart';
import 'package:one_gov_fx/helper/enum.dart';
import 'package:one_gov_fx/ui/page/Auth/signup.dart';
import 'package:one_gov_fx/state/authState.dart';
import 'package:one_gov_fx/widgets/customFlatButton.dart';
import 'package:one_gov_fx/widgets/newWidget/title_text.dart';
import 'package:provider/provider.dart';
import '../homePage.dart';
import 'signin.dart';

class WelcomePage extends StatefulWidget {
  WelcomePage({Key key}) : super(key: key);

  @override
  _WelcomePageState createState() => _WelcomePageState();
}

class _WelcomePageState extends State<WelcomePage> {
  Widget _submitButton() {
    return Container(
      margin: EdgeInsets.symmetric(vertical: 15),
      width: MediaQuery.of(context).size.width,
      child: CustomFlatButton(
        label: "Create Account",
        onPressed: () {
          var state = Provider.of<AuthState>(context, listen: false);
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => Signup(loginCallback: state.getCurrentUser),
            ),
          );
        },
        borderRadius: 30,
      ),
    );
  }

  Widget _loginButton() {
    return Container(
      margin: EdgeInsets.symmetric(vertical: 15),
      width: MediaQuery.of(context).size.width,
      child: CustomFlatButton(
        label: "Login",
        onPressed: () {
          var state = Provider.of<AuthState>(context, listen: false);
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => SignIn(loginCallback: state.getCurrentUser),
            ),
          );
        },
        borderRadius: 30,
      ),
    );
  }

  Widget _body() {
    return SafeArea(
      child: Container(
        padding: EdgeInsets.symmetric(
          horizontal: 40,
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            SizedBox(
              height: 80,
            ),
            Container(
              width: MediaQuery.of(context).size.width - 80,
              height: 80,
              child: Image.asset('assets/images/web-logo-250.png'),
            ),
            SizedBox(height: 50),
            TitleText(
              'Post Analysis, Connect with like minds and Follow traders you like',
              fontSize: 25,
            ),
            SizedBox(
              height: 200,
            ),
            _submitButton(),
            _loginButton(),
            Spacer(),
            Container(
              alignment: Alignment.bottomCenter,
              child: SizedBox(
                child: TitleText(
                  'Proudly Sponsored by One Government FX',
                  fontSize: 14,
                  fontWeight: FontWeight.w300,
                ),
              ),
            ),
            SizedBox(height: 30)
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    var state = Provider.of<AuthState>(context, listen: false);
    return Scaffold(
      body: state.authStatus == AuthStatus.NOT_LOGGED_IN ||
              state.authStatus == AuthStatus.NOT_DETERMINED
          ? _body()
          : HomePage(),
    );
  }
}
